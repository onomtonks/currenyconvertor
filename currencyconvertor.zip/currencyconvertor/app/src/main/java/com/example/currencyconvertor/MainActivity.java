package com.example.currencyconvertor;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public void convert(View view){
        EditText dollar=(EditText) findViewById(R.id.dollarid);
        Double Dollaramount=Double.parseDouble(dollar.getText().toString());
        Double poundamount=Dollaramount*0.75;
        Toast.makeText(MainActivity.this,poundamount.toString() +"pounds",Toast.LENGTH_SHORT).show();
        Log.i("amount",dollar.getText().toString());

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
            }
}